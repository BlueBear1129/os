# OS-sim
Simulation project for the dispatcher for CS475W at Whitworth University

This project simulates the CPU dispatch scheduler that is foundational to most operating systems. Part A of this project, the system design documentation, is listed in the file "Deliverable A", and the rest of the project is the implementation of the specifications in Deliverable A. 

This project was worked on by Aaron Borjas, Ty Heim, and Diana Diaz, at Whitworth University for CS475W, Operating Systems.
