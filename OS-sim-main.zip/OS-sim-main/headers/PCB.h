#ifndef PCB_H
#define PCB_H

#include <iostream>
using namespace std;

enum State {NEWWW, READY, WAITING, RUNNING, IORUN, EXIT};

//PCB class, contains information and functionality of a process control block
class PCB{
    private:
        int ID; //id of the process it is assigned to
        State state; //tracks the current state of the object
        float startWait;
        float avgWait;
        int sumWait;
        int countWait;
        int turnaround;
        int response;
    public:
        //default constructor
        //creates a new PCB object that sets the ID to the IDPool of the PC plus 1
        //sets the state of the PCB to NEW
        PCB();

        //parameter constructor for PCB
        //inputs - a process pointer for which the PCB is to be created
        //sets id to the next ID in the IDPool for PCB
        //sets the process of the PCB to input process
        //sets the state to new
        PCB(int ID);

        int getR();
        
        //function setState, sets the state of the current PCB to a specified state
        //inputs - an enum state: either new, ready, waiting, running, or exit
        //no outputs
        void setState(State s, int c);

        //function getState, gets the current state of the PCB
        //no inputs
        //outputs - returns the state of the PCB, which can be either new, ready, waiting, running, or exit
        State getState();

        //gets the time the process has spent in the waiting state
        //inputs - none
        //outputs - returns the current wait time of the PCB object that calls this function
        float getWT();

        //gets the turnaround time of the process (assuming the process is in the exit state)
        //inputs - none
        //outputs - returns the current wait time of the PCB object that calls this function
        float getTurnaround();
};

#endif