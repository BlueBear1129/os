#ifndef PROCESS_H
#define PROCESS_H

#include <vector>
#include "../headers/PCB.h"
using namespace std;

//int IDPool = 0;
//int IDPoolPCB = 0;
//enum State {NEW, READY, WAITING, RUNNING, EXIT};

class Process{
    private:
        int ID; //process id
        PCB* pcb; //pointer to PCB object
        int IOItr;
        int CPUItr;
        long long int arriveTime; //long long int (64 bit) for arrival time
        std::vector<int> cpuTimes; //vector to store cpu burst times 
        std::vector<int> ioTimes; //vector to store io burst times
        int avgWait; //average 
        int numWait; //increments the wait time
        long long int waitStart;
        
    public:
        //getters that didnt quite work for printing. fix later maybe
        // int getID() { return ID; }
        // string getCPUVec() {
        //     string out;
        //     for(int i = 0; i < cpuTimes.size(); i++) {
        //         out += cpuTimes.at(i) + ", ";
        //     }
        //     return out;
        // }
        // string getIOVec() {
        //     string out;
        //     for(int i = 0; i < ioTimes.size(); i++) {
        //         out += ioTimes.at(i) + ", ";
        //     }
        //     return out;
        // }


        //default constructor
        //assigns io and cpu itrs to 0, adds a new id that is one more than the IDPool value
        //creates a new PCB object for the current process object
        Process();

        //constructor for process that fills the cpuTime and ioTime vectors, as well as arrival time
        //similar to default constructor, io and cpu itrs are 0, a new id is created that us one more than the IDPool value
        Process(int arr, std::vector<int> c, std::vector<int> i, int ID);

        //copy constructor for process
        Process(const Process &old);

        // int getThruput();

        // void setThruput(int newPut);

        //function getNextCPUTime, gets the next cputime in the cpuTimes vector
        //no inputs
        //returns the value of the next cputime if it exists, otherwise returns -1 if it doesnt exist
        int getNextCPUTime();
        
        int getNextCPUTime(int c);
        //function 
        void setCPUTime(int next);

        PCB* getpcb();

        int getArriveTime();

        //function getNextIOTime, gets the next iotime in the iotimes vector
        //no inputs
        //returns the value of the next ioTime if it exists, otherwise returns -1 if it doesnt exist
        int getNextIOTime();

        void setIOTime(int next);

        //function checkEnd, checks if the process is over by checking the number of cpuBursts and ioBursts completed.
        bool checkEnd();

        //function to print out a process
        void output();

        void startWait(int c);

        //function to calculate avg wait time
        void doneWaiting(int c);
};

#endif