//#pragma once
#include "../headers/PCB.h"


PCB::PCB() {
    //ID = ++IDPoolPCB; 
    this->state = NEWWW;
    this->response = 0;
    this->sumWait = 0;
    this->countWait = 0;
    startWait = -1;
}

PCB::PCB(int ID) {
    //ID = ++IDPoolPCB;
    this->ID = ID;
    this-> state = NEWWW;
    this->response = 0;
    this->sumWait = 0;
    this->countWait = 0;
    startWait = -1;

}

int PCB::getR(){
    return response;
}


void PCB::setState(State s, int c) {
    switch (s){
        case WAITING: //START WAITING
            startWait = c;
            //cout << "Waiting started at " << c << endl; 
            break;
        case RUNNING:
            if ( startWait != -1){ //DONE WAITING
                sumWait += abs(c-startWait);
                countWait++;
                avgWait = float(sumWait) / float(countWait);
                startWait = -1;
            }
            if (response == 0){
                response = c;
            }
            break;
        case EXIT:
            turnaround = c;
            break;
    }
    
    
    
    
    state = s;

}

State PCB::getState(){
    return state;
}

float PCB::getWT(){
    return avgWait;
}

float PCB::getTurnaround() {
    return turnaround;
}
