//#pragma once

#include <vector>
#include <string>
#include <cstring>
#include <chrono>
#include "../headers/PCB.h"
#include "../headers/process.h"

Process::Process() {
    IOItr = 0;
    CPUItr = 0;
    //ID = ++IDPool;
    ID = 0;
    pcb = new PCB(ID);
    avgWait = 0;

}

Process::Process(int arr, std::vector<int> c, std::vector<int> i, int ID) {
    IOItr = 0;
    CPUItr = 0;
    this->ID = ID;
    //ID = ++IDPool;
    pcb = new PCB(ID);
    arriveTime = arr;
    cpuTimes = c;
    ioTimes = i;
    avgWait = 0;
}

Process::Process(const Process &old) {
    ID = old.ID;
    pcb = old.pcb;
    IOItr = old.IOItr;
    CPUItr = old.CPUItr;
    arriveTime = old.arriveTime;
    cpuTimes = old.cpuTimes;
    ioTimes = old.ioTimes;
    avgWait = 0;

}

// int Process::getThruput() {
//     return thruput;
// }

// void Process::setThruput(int newPut) {
//     thruput = newPut;
// }

void Process::setCPUTime(int next) {
    //cout <<"SETTING CPU TIME\n";
    if(CPUItr < cpuTimes.size()) {
        cpuTimes[CPUItr] = next;
        //cout << "CPU TIME SET\n";
    }
}

int Process::getNextCPUTime(){
    if (CPUItr != cpuTimes.size()){
        int x = cpuTimes[CPUItr++];
        //cout << ID << "is on its " << CPUItr << " CPU Burst out of "<< cpuTimes.size() << "\n";
        return x;
    }
    return -1;
}

int Process::getNextCPUTime(int c){
    if (CPUItr == 0){
        this->pcb->setState(RUNNING, c); //if the "next" cpu time is the first,
    }
    if (CPUItr != cpuTimes.size()){
        int x = cpuTimes[CPUItr++];
        //cout << ID << "is on its " << CPUItr << " CPU Burst out of "<< cpuTimes.size() << "\n";
        return x;
    }
    return -1;
}


PCB* Process::getpcb(){
    return pcb;
}

int Process::getArriveTime(){
    return arriveTime;
}

void Process::setIOTime(int next) {
    if(IOItr < ioTimes.size()) {
        ioTimes[IOItr] = next;
    }
}

int Process::getNextIOTime(){
    if (IOItr != ioTimes.size()){
        int x = ioTimes[IOItr++];
        cout << ID << " is on its " << IOItr << " IO Burst out of "<< ioTimes.size() << "\n";
        return x;
    }
    return -1;
}

bool Process::checkEnd(){
    if (IOItr >= ioTimes.size() && CPUItr >= cpuTimes.size()){
        return true;
    }
    return false;
}   

void Process::output(){
    cout << "ID : " << ID << endl;
    cout << "CPU Bursts Remaining : ";
    for (int i = CPUItr; i < cpuTimes.size(); i++){
        cout <<  i << ": " << cpuTimes[i] << " ";
    }
    cout << "\nIO Bursts Remaining : ";
    for (int i = IOItr; i < ioTimes.size(); i++){
        cout << i << ": " << ioTimes[i] << ", ";
    }
    cout << "\nState : "<< pcb->getState() << endl;
    cout << "\nAvgWaitTime: "<< pcb->getWT() << endl;
    
}

void Process::doneWaiting(int c){
    avgWait = avgWait * numWait;
    numWait++;
    avgWait = (numWait + c - waitStart)/numWait;
}

void Process::startWait(int c){
    waitStart = c;
}
