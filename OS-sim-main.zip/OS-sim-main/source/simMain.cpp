//Main file for the CPU dispatch sim project.
//contributors: Aaron Borjas, Ty Heim, Diana Diaz
//Created: 3/21/2022
//Last edited: 4/4/2022
//Resources: "Operating Systems: Internals and Design Principles" by William Stallings
//          Lectures by Pete Tucker, in MaCS department of Whitworth University
//          cpp reference for ostream: https://www.cplusplus.com/reference/ostream/ostream/
//          cpp reference for chrono https://www.cplusplus.com/reference/chrono/

#include <iostream> //cout and cin
#include <fstream> //file io
#include <vector> //for vectors
#include <queue> //queues
#include <ctime>
#include <thread>
#include <cstdlib>
#include <mutex>
#include <stdio.h>
#include <iomanip> //setprecision
//#include <windows.h>
#include <string> //to_string()
#include <cstring> //strcpy
#include <chrono>//high_resolution_clock, duration_cast, now()
#include "../headers/process.h" //process class, which has a PCB class in it (don't need enum State)
#include "../headers/PCB.h" //pcb class
//#include "process.cpp"
//#include "PCB.cpp" 
//above two lines fixes "Undefined reference to ..." but it is not a good solution
using namespace std;
// #define numProcessors 3
const int numProcessors = 3;
//enum State {NEWWW, READY, WAITING, RUNNING, IORUN, EXIT};

//function processStringGen: generates a string to add to a file for information regarding a process,
//          format will look like "Process #, Arrival time, CPUBurst1" at the very least, 
//          or "Process #, Arrival time, CPUBurst1, IOBurst1, CPUBurst2, IOBurst2, ..., CPUBurstN" at the most (N number of threads in the process)
//inputs - a unique, positive integer for process ID number (each process is unique), 
//          a timepoint (of high_resolution_clock type) that we can reference for arrival time. 
//          and positive integers representing the number of CPU and IO burst times.
//          numCPUBurst must be at least 1, because each process needs this value but numIOBurst can be 0
//outputs - returns a string in the format specified above, which is then appended to a file
string processStringGen(int processID, std::chrono::time_point<std::chrono::high_resolution_clock> start, int numCPUBurst, int numIOBurst, vector<Process>& processes) {
    //process string to add on to. format will look like "Process #, Arrival time, CPUBurst1" at the very least, 
    //or "Process #, Arrival time, CPUBurst1, IOBurst1, CPUBurst2, IOBurst2, ..., CPUBurstN" at the most (N number of threads in the process)
    string proc; 
    vector<int> cpuBursts, ioBursts;
    proc += to_string(processID); //appends the string version of the ID to the process string
    
    proc += ", ";

    //calculates the time (in nanoseconds) since the initial clock start time, adds the string of that to process string
    //we use auto to assign the type to the type now() returns, so we don't have to type out all of std::chrono[...].
    //we do not use auto in the definition so we can be sure which clock we are using 
    //(there are options of steady_clock, system_clock, and high_resolution_clock). The types are not compatible
    auto end = std::chrono::high_resolution_clock::now();  

    //calculte the time from start time to end time in nanoseconds, then convert it to a 64bit int
    //we chose nanoseconds because anything of higher value would have "repeat" times, and we want distinct arrival times
    long long arrTime = std::chrono::duration_cast<std::chrono::nanoseconds>(end-start).count(); 
    proc += to_string(arrTime); //converts the long long int to string and adds it to proc as arrival time.

    proc += ", ";

    int j = 0; //counter to add # of io bursts to process string
    for(int i = 0; i < numCPUBurst; i++) {
        int cpuBurst = (rand()%200)+1; //cpu burst time is random number between 1 and 200 (so we can differentiate this and ioburst for testing)
        cpuBursts.push_back(cpuBurst); //pushes cpuBurst to back of cpuBursts vector
        proc += to_string(cpuBurst); //add the cpuBurst time (as string) to process
        if(i+1 < numCPUBurst || j < numIOBurst) { //if either the next cpu burst is not the last cpuBurst or if the current io burst is not the last ioburst
            proc += ", "; //add a comma
        }
        //the following lines in the for loop add io bursts to process string if they exist
        if(j < numIOBurst) { //if j is less than the number of io bursts 
            int ioBurst = (rand()%200)+200; //io burst time is random number between 200 and 400 (different range than cpuburst for testing)
            ioBursts.push_back(ioBurst); //pushs ioburst random value to ioBursts vector
            proc += to_string(ioBurst); //add io burst time (as string) to process
            if(i+1 < numCPUBurst && j+1 <= numIOBurst) {//if there is another cpuburst and if the next ioburst is less than the total number of IO bursts
                proc += ", "; //add a comma
            }
        }
        j++; //increment j
        
        
    }
    Process newProc = Process(arrTime, cpuBursts, ioBursts, processID);
    processes.push_back(newProc);

    proc += "\n"; //add a new line to seperate the entries
    return proc; //return the process string
}


//process file generator, creates a file or writes over an existing file with information about processes to simulate
//inputs - a reference to an output file stream object (opened in ios::app append mode) to write to and a positive integer for number of lines to write
//         a pointer to a process vector that we add the processes to as we generate the file
//outputs - nothing, but creates a new file titled "datafile.dat" containing processes and features of processes
//          such features include process ID, which is unique, arrival time (since program was executed), and 
//          float values for CPU and IO burst times.
void procFileGen(fstream& file, int numLines, vector<Process>& processes) {
    //file.open("../bin/processData.dat", ios::out); //open the file in output mode
    if(file.fail()) { //if opening the file fails
        cout << "could not open file in procFileGen\n"; //say what went wrong
    } else { //if the file opened fine
        file.seekp(0, ios::beg); //set the position of the next character to be inserted at the beginning
        auto start = std::chrono::high_resolution_clock::now(); //sets the "starting" point to measure arrival time off of
        
        for(int i = 0; i < numLines; i++) { //go through as many lines of the file as specified in parameter
            int procID = i; //value of process id, increments every for loop. process IDs have to be unique.
            int numCPUBurst = (rand()%3)+1; //tells us how many cpu burst to add to each process. 
            int numIOBurst = (rand()%2); //tells us how many io bursts to add to each process

            string proc = processStringGen(procID, start, numCPUBurst, numIOBurst, processes); //generates a string with process info with the processStringGen function

            file << proc; //write the process info string to the file
        }
    }
    file.close(); //close the file to avoid issues reading/writing later
}

//generates data and outputs it to a csv file to create graphs with
//inputs - an output file stream reference to a file that we will write to, 
//          a string for the algorithm to used, which is the column name of the csv file. expected inputs are "Red Robin {timeq}", "FCFS", "SPN" and "Load Sharing {numProcessors}"
//          floating point values for times to enter to the file (throughput, turnaround, wait time, response time, utilization percent)
//outputs - returns an integer based on status of function. -1 is fail, and 1 is success
//creates a csv file with information about the different process scheduling algorithms implemented
int dataGen(fstream& out, string algorithm, float throughput, float turnaround, float wait, float response, float utilPercent, float cs = 0) {
    if(out.fail()) { //if failed to open file
        return -1; //-1 is fail code
    }
    else {
        out.seekp(0, ios::beg); //go to the beginning of the file
        //outputs to csv in format:
        // algorithm | throughput | turnaround | wait | response | utilPercent |
        out << algorithm << ",";
        out << throughput << ",";
        out << turnaround << ",";
        out << setprecision(10) << wait << ",";
        out << response << ",";
        out << cs << ",";
        out << utilPercent << "\n";
    }
    return 1;
    out.close();
}

//shows the size of a file in bytes
//Input: input file stream reference (file should be opened in read mode)
//Output: returns an integer with the size of the file in bytes
int getFileSize(fstream& file){

	int size = file.tellg(); //gets the size from tellg as an integer (size is in bytes)
	file.seekg(0, ios::beg); //return cursor to beginning for future operations (so we don't have to close again)
	return size; //returns size as an int
}


//gets average wait time of all processes in a queue of processes that has gone through the processor
//inputs - a queue of process pointers that have gone through the processor, in the "EXIT" state
//outputs - returns the average wait time, the sum of wait times of every process divided by the total number of processes
float averageWaitTime(queue<Process*> h){
    float sum = 0; //sum of all wait times
    int s =  h.size(); //size of the input queue
    for (int i = 0; i < s; i++){ //loop through queue
        sum += h.front()->getpcb()->getWT(); //add the wait time of the front object of the queue to sum
        h.pop(); //remove the first object of the queue so we can get the next wait time
    }
    return sum/s; //returns average wait time
}

//gets average wait time of all processes in a vector of processes that has gone through the processor
//inputs - a vector of process pointers that have gone through the processor, in the "EXIT" state
//outputs - returns the average wait time, the sum of wait times of every process divided by the total number of processes
float averageWaitTime(vector<Process*> h) {
    float sum = 0; //sum of all wait times
    int s =  h.size(); //size of the input vector
    for (int i = 0; i < s; i++){ //loop through vector
        sum += h.at(i)->getpcb()->getWT(); //add the wait time of the ith object to the sum
    }
    return sum/s; //returns average wait time
}

//average response time - gets the average time from a process enters the READY state to when it enters the RUNNING state for the first time
//inputs - a queue of process pointers that are in the EXIT state
//outputs - returns avg response time: sum of response times divided by size of the queue
float averageResponseTime(queue<Process*> h){
    float sum = 0; //sum of all response times
    int s =  h.size(); //size of input queue
    for (int i = 0; i < s; i++){ //loop through queue
        sum += h.front()->getpcb()->getR(); //add the response time of the front object of the queue to the sum
        h.pop(); //remove the first element of the queue and shift left
    }
    return sum/s; //return avg response time
}

//average response time - gets the average time from a process enters the READY state to when it enters the RUNNING state for the first time
//inputs - a vector of process pointers that are in the EXIT state
//outputs - returns avg response time: sum of response times divided by size of the queue
float averageResponseTime(vector<Process*> h){
    float sum = 0; //sum of all response times
    int s =  h.size(); //size of input vector
    for (int i = 0; i < s; i++){ //loop through vector
        sum += h.at(i)->getpcb()->getR(); //add the response time of the ith object of the vector to the sum
    }
    return sum/s; //return avg response time
}

//average turnaround time, averages the time it took for all processes in the input queue to reach the EXIT state
//inputs - a queue of process pointers, which are all in the EXIT state
//outputs - returns the average response time of items in the input queue
float averageTurnaround(queue<Process*> h) {
    float sum = 0; //sum of all turnaround times
    int s = h.size(); //size of input queue
    for(int i = 0; i < s; i++) {
        sum += h.front()->getpcb()->getTurnaround(); //adds the turnaround of front process of h queue
        h.pop(); //remove the first element of the queue and shift left
    }
    return sum/s; //return avg turnaround time
}

//average turnaround time, averages the time it took for all processes in the input vector to reach the EXIT state
//inputs - a vector of process pointers, which are all in the EXIT state
//outputs - returns the average response time of items in the input queue
float averageTurnaround(vector<Process*> h) {
    float sum = 0; //sum of all response times
    int s =  h.size(); //size of input vector
    for (int i = 0; i < s; i++){ //loop through vector
        sum += h.at(i)->getpcb()->getTurnaround(); //add the turnaround time of the ith object of the vector to the sum
    }
    return sum/s; //return avg response time
}

//function to implement a SPN uniprocessor process scheduling algorithm. 
//inputs - a vector of processes that have unique ids, arrival times, and sequences of cpu and io bursts.
//         a positive integer that represents a time quantum that each process is granted "time" to run. for example, if timeq = 10, each process runs for 10 clock ticks and is then moved to the back of processes in ready state
//outputs - calculates a throughput time, average turnaround times, average wait times, average response times, and processor utilization % and puts to a csv file
void RoundRob(vector<Process> p, int timeQ) {
    vector<Process*> Ready;
    vector<Process*> Waiting;
    vector<Process*> Exit;
    //string test;

    int sizeProc = p.size(); //How many processes there are
    int clock = 0; //clock ticks to keep track of 
    bool cpuReady = true; //is the cpu ready?
    bool ioReady = true; //is the ioReady?
    Process* pRunCPU = NULL; //a process pointer of the running cpu process
    Process* pRunIO = NULL; //a process pointer of the running io process
    int util = 0;
    int countCS;
    int sumCSTime;
    bool cs = false;
    //Push all the processes into the ready vector 
    for (int i = 0; i < p.size(); i++){
        int arriv = p[i].getArriveTime();
        //p[i].output();
        //Sleep(arriv); //can't use windows.h on linux
        //following line is fix for not being able to use windows.h on linux
        //std::this_thread::sleep_for(std::chrono::nanoseconds(arriv)); //uses chrono and thread, this_thread is the current process (doesnt split threads)

        Ready.push_back(&p[i]); //push the ith element of a process vector to the back of the ready queue
        //Ready.at(i).setState
        //Ready[i]->setThruput(0); //sets the thruput of the process to 0
        Ready[i]->getpcb()->setState(READY, 0);

    }
    //cout << "after for\n";
    //cin >> test;
    while(Exit.size() < sizeProc) { //loop until the size of the exit vector is greater than or equal to the number of input processes
        int ticksCPU = 0; //keeps track of current process' current CPU burst
        int ticksIO = 0; //keeps track of current process' current IO burst
        clock++; //increment clock
        if (cs){sumCSTime++;}
        if(!cpuReady && !(Ready.front()->checkEnd())) { //if the cpu is running and the process is not at its end (the cpu is in use)
            util+=timeQ; //increment utilization time
            //util++;
            cout << "util: " << util << "\tclock: " << clock << endl;
        }
        
        if(cpuReady && !Ready.empty()) { //if the cpu is ready for a process and ready is not empty
            //cout << "if cpuready and ready not empty:\n";
            //cin >> test;
            cs = false;
            Ready.front()->getpcb()->setState(RUNNING, clock); //change state of the front of the queue
            //cout << "before tickscpu decl\n";
            ticksCPU = Ready.front()->getNextCPUTime(); //get the CPUtime of the new process
            //cout << "after tickscpu decl\n";
            pRunCPU = Ready.front(); //set the runnign process to the first process
            Ready.erase(Ready.begin()); //remove the first element of ready
            cpuReady = false; //cpu is no longer ready
            //cout << "end ifcpuready\n";
            //cout << "TICKSCPU: " << ticksCPU << endl;
        }
        if(pRunCPU != NULL) {//if there is a currently running process
            // if(!cpuReady) { //if the cpuready is false (the cpu is in use)
            //     util++; //increment utilization time
            // }
            //ticksCPU--; //decrement the time that has been taken for this process
            //cout << "pruncpu != null\n";
            //cin >> test;
            if(ticksCPU > 0) { //if there are still ticks left
                //cout << "tickscpu > 0\n";
                //cin >> test;

                if(ticksCPU > timeQ) { //if there is more time left than timeQuantum 
                    //cout << "ticksCPU > timeq\n";
                    //cin >> test;

                    ticksCPU -= timeQ;//decrement tickscpu by timeq time
                    //cout << "\nAFTER CHANGE ticksCPU = " << ticksCPU << "\n\n";
                    pRunCPU->setCPUTime(ticksCPU); //set the cputime to the current value of tickscpu burst
                    //cout << "set cpu time to tickscpu\n";

                    cpuReady=true;
                    Ready.push_back(pRunCPU); //push the process to the ready state queue
                    pRunCPU->getpcb()->setState(READY, clock);
                    pRunCPU=NULL;
                    //cout << "SENT TO READY in cpu\n";
                }
            }
            else if(ticksCPU <= timeQ) { //if burst time is smaller than quantum, then last cycle for this burst
                    //cout << "burst time smaller than quantum and not done\n";
                    //cin >> test;
                    pRunCPU->setCPUTime(ticksCPU);
                    //ticksCPU = 0;

                    if(ticksCPU <= 0) { //if the time left in the burst is less than 0
                        //cout << "ticksCPU <= 0\n";
                        cpuReady=true; //signal current process is done
                        if(pRunCPU->checkEnd()){ //if the current process is done with its alloted burst time
                            
                            Exit.push_back(pRunCPU); //push the process to the exit state queue
                            pRunCPU->getpcb()->setState(EXIT, clock);
                            cs = true;
                            countCS++;
                            //cout << "SENT TO EXIT in cpu\n";
                            
                        } else { //if the process is not done (there are more cpu bursts)
                            pRunCPU->startWait(clock);
                            Waiting.push_back(pRunCPU); //push the process to the waiting queue
                            pRunCPU->getpcb()->setState(WAITING, clock);
                            //cout << "SENT TO WAITING in cpu\n";
                        }
                        pRunCPU ->output();
                        pRunCPU = NULL; //making sure things work as intended
                    }
                }
        }

        if(ioReady && !Waiting.empty()) { //if the io is ready for a process and waiting isn't empty
            Waiting.front()->getpcb()->setState(IORUN, clock); //change state of the front of the queue
            ticksIO = Waiting.front()->getNextIOTime(); //get the CPUtime of the new process
            pRunIO = Waiting.front(); //set the runnign process to the first process
            Waiting.erase(Waiting.begin()); //remove the first element of ready
            ioReady = false; //cpu is no longer ready
            //cout << "TICKSIO: " << ticksCPU << endl;
        }
        if(pRunIO != NULL) {//if there is a currently running process
            //ticksCPU--; //decrement the time that has been taken for this process
            //cout << "prunio != null\n";
            //cin >> test;
            if(ticksIO > 0) { //if there are still ticks left
                //cout << "ticksio > 0\n";
                //cin >> test;

                if(ticksIO > timeQ) { //if there is more time left than timeQuantum 
                    //cout << "ticksio > timeq\n";
                    //cin >> test;

                    ticksIO -= timeQ;//decrement tickscpu by timeq time
                    //cout << "ticksIO = " << ticksIO << endl;
                    pRunIO->setIOTime(ticksIO); //set the cputime to the current value of tickscpu burst
                    //cout << "set io time to tickscpu\n";

                    ioReady=true;
                    Ready.push_back(pRunIO); //push the process to the exit state queue
                    pRunIO->getpcb()->setState(READY, clock);
                    pRunIO=NULL;
                    //cout << "SENT TO READY in io\n";
                }
                
            }
            else if(ticksIO <= timeQ) { //if burst time is smaller than quantum, then last cycle for this burst
                //cout << "burst time smaller than quantum and not done\n";
                //cin >> test;
                pRunIO->setIOTime(ticksIO);
                //ticksIO -= timeQ;

                if(ticksIO <= 0) { //if the time left in the burst is less than 0
                    //cout << "if ticks io <= 0\n";
                    ioReady=true; //signal current process is done
                    if(pRunIO->checkEnd()){ //if the current process is done with its alloted burst time
                        Exit.push_back(pRunIO); //push the process to the exit state queue
                        pRunIO->getpcb()->setState(EXIT, clock);
                        //cout << "SENT TO EXIT in io\n";
                        
                    } else { //if the process is not done (there are more IO bursts)
                        //pRunIO->startWait(clock);
                        Ready.push_back(pRunIO); //push the process to the waiting queue
                        pRunIO->getpcb()->setState(READY, clock);
                        //cout << "SENT TO READY in io\n";
                    }
                    pRunIO -> output();
                    pRunIO = NULL; //making sure things work as intended
                }
            }
        }
    }

    //calculate times now
    float throughput = float(sizeProc)/float(clock); //throughput is generally # of processes over time quantum, which is the amount of clock ticks in our case
    float turnaround = averageTurnaround(Exit)*timeQ; //gets the average time of all processes from entering ready state to exit state
    float avgWait = averageWaitTime(Exit); //gets average wait time of all processes that have completed (all time spent in waiting state)
    float avgResponse = averageResponseTime(Exit); //gets average response time of all processes that have completed (time from first ready until first running states)
    float avgCS = float(sumCSTime)/float(countCS);
    //float avgContextSwitch = averageContactSwitch(Exit); //
    cout << "util: " << util << " clock: " << clock << endl;
    float utilTime = (float(util)/float(clock))*100; //utilization % = (time in running / total time) * 100

    string filename2 = "../bin/outputData.csv"; //string for relative path of file to open (for writing output of scheduling algorithms)
    fstream outData(filename2, ios::out | ios::app); //open specified filename in output mode  (write)
    string algName = "Round Robin " + to_string(timeQ);
    dataGen(outData,algName, throughput, turnaround, avgWait, avgResponse, utilTime, avgCS);
    outData.close();
}

//function to implement a FCFS process scheduling algorithm. 
//inputs - a vector of processes that have unique ids, arrival times, and sequences of cpu and io bursts
//outputs - calculates a throughput time, average turnaround times, average wait times, average response times, and processor utilization % and puts to a csv file
void firstComeFirstServe(vector<Process> p){
    queue<Process*> Ready; //ready queue of process*
    queue<Process*> Waiting; //waiting queue of process*
    queue<Process*> Exit; //exit queue of process*
    //Add all processes to new, with their arrival times, then onto ready
    int numProc = p.size();
    int countCS;
    int sumCSTime;
    bool cs = false;
    for (int i = 0; i < p.size(); i++){
        int arriv = p[i].getArriveTime();
        //p[i].output();
        //Sleep(arriv); //can't use windows.h on linux
        //following line is fix for not being able to use windows.h on linux
        //std::this_thread::sleep_for(std::chrono::nanoseconds(arriv)); //uses chrono and thread, this_thread is the current process (doesnt split threads)

        Ready.push(&p[i]); //push the ith element of a process vector to the back of the ready queue
        //Ready.back()->setThruput(0); //sets the thruput of the process to 0
        Ready.back()->getpcb()->setState(READY, 0);
    }

    cout << "All processes put onto Ready queue\n"; //prints "all processes put onto Ready queue"
    bool cpuReady = true; //sets the cpuready state to true
    bool ioReady = true; //sets the ioready state to false

    int clock = 0; //starts the clock at 0 for discrete event timer

    Process* pRunCPU = NULL; //process pointer for process currently in cpu
    Process* pRunIO = NULL; //process pointer for process currently in IO

    int ticksCPU = 0; //ticks til the current cpu process is done in cpu
    int ticksIO = 0; //ticks til the current IO process is done in cpu
    int util = 0;

    while(Exit.size() < numProc){ //while the # of processes in the exit state is less than total number of processes
        clock++; //count clock tick (one clock tick per discrete event)
        
        //cout << "Clock: " << clock << endl;
        //cout << "ticksIO: " << ticksIO << endl;
        //cout << "ticksCPU: " << ticksCPU << endl;

        if(!cpuReady) { //if the cpuready is false (the cpu is in use)
            util++; //increment utilization time
        }

        //Check if CPU is ready for next process, wait until it is
        if (cpuReady && !Ready.empty()){ //if the cpu is ready for processes and the ready state has processes
            if (Ready.front()->getpcb()->getState() == WAITING){
                Ready.front()->doneWaiting(clock);
            }
            Ready.front()->getpcb()->setState(RUNNING, clock); //change state of the front of the queue
            ticksCPU = Ready.front()->getNextCPUTime(); //get the CPUtime of the new process
            //cout << "ticksCPU: " << ticksCPU << endl;
            pRunCPU = Ready.front(); //assign front of queue to the cpu
            Ready.pop(); //remove from ready since now running
            cpuReady = false; //cpu is now running this process
            //cout << "New process in CPU\n";
            pRunCPU ->output();
        } else if (pRunCPU != NULL){ //if the cpu is executing a process or ready queue is empty
            ticksCPU--; //decrements the amount of time left for the process
            if (ticksCPU <= 0){ //if the tick number is 0 (the process is done)
                //cout << "CPU Done\n";
                cpuReady=true; //signal current process is done
                if(pRunCPU->checkEnd()){ //if the current process is done with its alloted burst time
                    Exit.push(pRunCPU); //push the process to the exit state queue
                    pRunCPU->getpcb()->setState(EXIT, clock);
                    
                } else { //if the process is not done (there are more cpu bursts)
                    pRunCPU->startWait(clock);
                    Waiting.push(pRunCPU); //push the process to the waiting queue
                    pRunCPU->getpcb()->setState(WAITING, clock);
                }
                pRunCPU ->output();
                pRunCPU = NULL; //making sure things work as intended
            }
        }
        if (ioReady && !Waiting.empty()){
            Waiting.front()->getpcb()->setState(IORUN, clock);
            ticksIO = Waiting.front()->getNextIOTime();
            //cout << "ticksIO: " << ticksIO << endl;
            pRunIO = Waiting.front(); //assign front of queue to the cpu
            Waiting.pop(); //remove from ready since now running
            ioReady = false; //cpu is now running this process
            //cout << "New process in IO\n ";
            pRunIO ->output();
        } else if (pRunIO != NULL) { //if the cpu is executing a process or ready queue is empty
            ticksIO--; //decrements the amount of time left for the process
            if (ticksIO <= 0){ //if the tick number is 0 (the process is done)
                //cout << "IO Done\n";
                ioReady=true; //signal current process is done
                if(pRunIO->checkEnd()){ //if the current process is done with a
                    pRunIO->getpcb()->setState(EXIT, clock);
                    Exit.push(pRunIO);
                } else {
                    Ready.push(pRunIO);
                    pRunIO->getpcb()->setState(READY, clock);
                }
                pRunIO ->output();
                pRunIO = NULL;
            }
        }
    }
        //Move finished process to either exit or waiting depending on if at end of cpu and 
        //Run first ready 

    //calculate times now
    float throughput = float(p.size())/float(clock); //throughput is generally # of processes over time quantum, which is the amount of clock ticks in our case
    float turnaround = averageTurnaround(Exit); //gets the average time of all processes from entering ready state to exit state
    float avgWait = averageWaitTime(Exit); //gets average wait time of all processes that have completed (all time spent in waiting state)
    float avgResponse = averageResponseTime(Exit); //gets average response time of all processes that have completed (time from first ready until first running states)
    //float avgContextSwitch = averageContactSwitch(Exit); //
    float utilTime = (float(util)/float(clock))*100; //utilization % = (time in running / total time) * 100

    string filename2 = "../bin/outputData.csv"; //string for relative path of file to open (for writing output of scheduling algorithms)
    fstream outData(filename2, ios::out | ios::app); //open specified filename in output mode  (write)
    dataGen(outData,"FCFS", throughput, turnaround, avgWait, avgResponse, utilTime);
    outData.close();
    //cout << averageWaitTime(Exit);
    //string s;
    //cin >> s;
}

//function to implement a load sharing multiprocessor process scheduling algorithm. 
//inputs - a vector of processes that have unique ids, arrival times, and sequences of cpu and io bursts
//outputs - calculates a throughput time, average turnaround times, average wait times, average response times, and processor utilization % and puts to a csv file
int loadSharing(vector<Process> p){
    queue<Process*> Ready; //ready queue of process*
    queue<Process*> Waiting; //waiting queue of process*
    queue<Process*> Exit; //exit queue of process*
    //Add all processes to new, with their arrival times, then onto ready
    int numProc = p.size();
    for (int i = 0; i < p.size(); i++){
        int arriv = p[i].getArriveTime();
        //Sleep(arriv); //can't use windows.h on linux
        //following line is fix for not being able to use windows.h on linux
        //std::this_thread::sleep_for(std::chrono::nanoseconds(arriv)); //uses chrono and thread, this_thread is the current process (doesnt split threads)

        Ready.push(&p[i]); //push the ith element of a process vector to the back of the ready queue
        //Ready.back()->setThruput(0); //sets the thruput of the process to 0
        Ready.back()->getpcb()->setState(READY, 0);
    }
    cout << "All processes put onto Ready queue\n"; //prints "all processes put onto Ready queue"
    bool cpuReady[numProcessors]; //sets the cpuready state to true
    for(int i = 0; i < numProcessors; i++){
        cpuReady[i]=true;
    }
    bool ioReady = true; //sets the ioready state to false

    int clock = 0; //starts the clock at 0 for discrete event timer
    Process* pRunCPU[numProcessors]; //process pointer for process currently in cpu
    for(int i = 0; i < numProcessors; i++){
        pRunCPU[i]=NULL;
    }
    Process* pRunIO = NULL; //process pointer for process currently in IO
    int ticksCPU[numProcessors]; //ticks til the current cpu process is done in cpu
    for(int i = 0; i < numProcessors; i++){
        ticksCPU[i]=0;
    }
    int ticksIO = 0; //ticks til the current IO process is done in cpu
    bool CPURunning[numProcessors];
    for(int i = 0; i < numProcessors; i++){
        CPURunning[i] = false;
    }

    //initialize utilization times of each processor.
    int utilTimes[numProcessors];
    for(int i = 0; i < numProcessors; i++) {
        utilTimes[i] = 0;
    }

    while(Exit.size() < numProc){ //while the # of processes in the exit state is less than total number of processes
        clock++; //count clock tick (one clock tick per discrete event)
        //cout << "Clock: " << clock << endl;
        //cout << "ticksIO: " << ticksIO << endl;
        //cout << "ticksCPU: " << ticksCPU << endl;
        //cout << Exit.size() << endl;
        //cout << numProc << endl;

        //Check if CPU is ready for next process, wait until it is
        for(int i = 0; i < numProcessors; i++){
            if(!cpuReady[i]) {
                utilTimes[i]++;
            }
            //cout << "PROCESSOR " << i << endl;
            if (!Ready.empty() && !CPURunning[i]){ //if the cpu is ready for processes and the ready state has processes
                Ready.front()->getpcb()->setState(RUNNING, clock); //change state of the front of the queue
                ticksCPU[i] = Ready.front()->getNextCPUTime(); //get the CPUtime of the new process
                //cout << "ticksCPU: " << ticksCPU[i] << endl;
                pRunCPU[i] = Ready.front(); //assign front of queue to the cpu
                Ready.pop(); //remove from ready since now running
                cpuReady[i] = false; //cpu is now running this process
                //cout << "New process in CPU " << i << " \n";
                CPURunning[i] = true;

                //string s;
                //cin >> s;
            } else if (pRunCPU[i] != NULL){ //if the cpu is executing a process or ready queue is empty
                ticksCPU[i]--; //decrements the amount of time left for the process
                if (ticksCPU[i] <= 0){ //if the tick number is 0 (the process is done)
                    //cout << "CPU " << i << " Done\n";
                    CPURunning[i] = false;
                    cpuReady[i]=true; //signal current process is done
                    if(pRunCPU[i]->checkEnd()){ //if the current process is done with its alloted burst time
                        pRunCPU[i]->getpcb()->setState(EXIT, clock);
                        Exit.push(pRunCPU[i]); //push the process to the exit state queue

                        //cout << " *****************CPU**********PUSHED TO EXIT********************** \n";
                        //string s;
                        //cin >> s;
                    } else { //if the process is not done (there are more cpu bursts)
                        Waiting.push(pRunCPU[i]); //push the process to the waiting queue
                        pRunCPU[i]->getpcb()->setState(WAITING, clock);
                    }
                    pRunCPU[i] = NULL; //making sure things work as intended
                }
            }
        }
        if (ioReady && !Waiting.empty()){
            Waiting.front()->getpcb()->setState(IORUN, clock);
            ticksIO = Waiting.front()->getNextIOTime();
            //cout << "ticksIO: " << ticksIO << endl;
            pRunIO = Waiting.front(); //assign front of queue to the cpu
            Waiting.pop(); //remove from ready since now running
            ioReady = false; //cpu is now running this process
            //cout << "New process in IO \n ";
            //pRunIO->output();
        } else if (pRunIO != NULL) { //if the cpu is executing a process or ready queue is empty
            ticksIO--; //decrements the amount of time left for the process
            
            if (ticksIO <= 0){ //if the tick number is 0 (the process is done)
                //cout << "IO Done\n";
                ioReady=true; //signal current process is done
                if(pRunIO->checkEnd()){ //if the current process is done with a
                    Exit.push(pRunIO);
                    pRunIO->getpcb()->setState(EXIT, clock);
                    //cout << " **********IO*****************PUSHED TO EXIT********************** \n";
                    //string s;
                    //cin >> s;
                } else {
                    pRunIO->getpcb()->setState(READY, clock);
                    Ready.push(pRunIO);
                }
                pRunIO = NULL;
            }
        }
    }
    //cout << averageWaitTime(Exit);
    //cout << "CLOCK " << clock << endl;
    float utilSum = 0;
    for(int i = 0; i < numProcessors; i++) {
        utilSum += (utilTimes[i]/(float(clock)*numProcessors)) * 100;
        cout << "utiltimes[" << i << "]: " << utilTimes[i]/float(clock) << endl;
        //cout << "sum of all "
    }
    cout << "END CLOCK IS: " << clock << endl;
    float utilAvg = utilSum/float(numProcessors);
    
    //calculate times now
    float throughput = float(p.size())/float(clock); //throughput is generally # of processes over time quantum, which is the amount of clock ticks in our case
    float turnaround = averageTurnaround(Exit); //gets the average time of all processes from entering ready state to exit state
    float avgWait = averageWaitTime(Exit); //gets average wait time of all processes that have completed (all time spent in waiting state)
    float avgResponse = averageResponseTime(Exit); //gets average response time of all processes that have completed (time from first ready until first running states)
    //float avgContextSwitch = averageContactSwitch(Exit); //
    
    //****** doesn't work correctly yet********
    float utilTime =  ((utilAvg))*100; //utilization = time in running / total time 


    string filename2 = "../bin/outputData.csv"; //string for relative path of file to open (for writing output of scheduling algorithms)
    fstream outData(filename2, ios::out | ios::app); //open specified filename in output mode  (write)
    string algName = "Load Sharing " + to_string(numProcessors);
    dataGen(outData, algName, throughput, turnaround, avgWait, avgResponse, utilSum);
    outData.close();
    return clock;
}

//function compare, compares the io or cpu burst times of two processes.
//inputs - two processes that have their cpu and io burst times set. an integer that has the values 0 or 1: 0 represents checking cpu bursts, 1 is io bursts
//outputs - returns 1 if the first process' cpu or io burst time is less than the second process' cpu or io burst time
//          returns 0 if the process 1's cpu/io burst time is greater than or equal to process 2's cpu/io burst time. 
//          returns -1 if no comparison was made
int compare(Process uno, Process dos, int cpuOrIO) {
    if(cpuOrIO == 0 && (uno.getNextCPUTime() > 0 && dos.getNextCPUTime() > 0)) {
        if(uno.getNextCPUTime() < dos.getNextCPUTime()) {
            return 1; //1 means cputime of proc1 is less than proc2
        }
        else {
            return 0; //0 means that cputime of proc1 is greater than or equal to proc2
        }
    }
    else if(cpuOrIO == 1 && (uno.getNextIOTime()>0 && dos.getNextIOTime()>0)) {
        if(uno.getNextIOTime() < dos.getNextIOTime()) {
            return 1; //1 means cpu time of proc1 is less than proc2
        }
        else {
            return 0; //0 means cpu time of proc2 is greater than or equal to proc2
        }
    }
    return -1; //return false if none of conditions are met.
}

//function sort, which sorts (with selection sort) processes in a vector by their cpu/io burst times
//inputs - a reference to a vector of processes (so we can change the values of the referenced process, as required by SPN)
//outputs - none, but sorts the values of the input vector of processes
void selectSort(vector<Process*>& readyProcs) {
    int minIndex, i, j; //value to hold the index of the minimum value. also i and j
    for(i = 0; i < readyProcs.size(); i++) { //for loop starts at 0 and repeats n-1 times
        minIndex = i; //index of minimum value is initially set to i
        for(j = i+1; j < readyProcs.size(); j++) { //loops from i+1 to n (checks all next elements of the array after i)
            if(readyProcs[j]->getNextCPUTime() < readyProcs[minIndex]->getNextCPUTime()) { //if the current value of the array is less than the value of the array at minIndex
                minIndex = j; //set the minimum index to index j
                //cout << "readyProcs[" << j << "]: " << readyProcs[j] << endl;
            }
            
        }
        swap(readyProcs[i], readyProcs[minIndex]); //swaps the values of arr[i] and arr[minIndex], so that the smaller value goes to the lower index
    }
}


//function to implement a SPN uniprocessor process scheduling algorithm. 
//inputs - a vector of processes that have unique ids, arrival times, and sequences of cpu and io bursts
//outputs - calculates a throughput time, average turnaround times, average wait times, average response times, and processor utilization % and puts to a csv file
void shortestProcessNext(vector<Process> p) {
    vector<Process*> Ready;
    vector<Process*> Waiting;
    vector<Process*> Exit;
    //vector<Process> sorted;
    //because it is non-preemptive, if a new process is added during execution of the next, the first must finish execution before the next executes. 
    //processes that are waiting are sorted only when the first process finishes execution. then, the process that is first executes.
    //we want to sort the waiting queue, since that is where processes are added at their arrival time.
    
    //*******following code sets up SPN*********
    //Add all processes to ready, with their arrival times, then onto ready
    int numProc = p.size();
    for (int i = 0; i < p.size(); i++){
        int arriv = p[i].getArriveTime();
        //p[i].output();
        //Sleep(arriv); //can't use windows.h on linux
        //following line is fix for not being able to use windows.h on linux
        //std::this_thread::sleep_for(std::chrono::nanoseconds(arriv)); //uses chrono and thread, this_thread is the current process (doesnt split threads)

        Ready.push_back(&p[i]); //push the ith element of a process vector to the back of the ready queue
        //Ready[i]->setThruput(0); //sets the thruput of the process to 0
        Ready[i]->getpcb()->setState(READY, 0);
    }
    cout << "All processes put onto Ready queue\n"; //prints "all processes put onto Ready queue"
    bool cpuReady = true; //sets the cpuready state to true
    bool ioReady = true; //sets the ioready state to false
    int clock = 0; //starts the clock at 0 for discrete event timer

    Process* pRunCPU = NULL; //process pointer for process currently in cpu
    Process* pRunIO = NULL; //process pointer for process currently in IO

    int ticksCPU = 0; //ticks til the current cpu process is done in cpu
    int ticksIO = 0; //ticks til the current IO process is done in cpu
    int util = 0; //counter for processor utilization
    //******SETUP DONE**********

    while(Exit.size() < numProc){ //while the # of processes in the exit state is less than total number of processes
        clock++; //count clock tick (one clock tick per discrete event)
        //cout << "Clock: " << clock << endl;
        //cout << "ticksIO: " << ticksIO << endl;
        //cout << "ticksCPU: " << ticksCPU << endl;
        if(!cpuReady) { //if the cpuready is false (the cpu is in use)
            util++; //increment utilization time
        }
        //Check if CPU is ready for next process, wait until it is
        if (cpuReady && !Ready.empty()){ //if the cpu is ready for processes and the ready state has processes
            Ready.front()->getpcb()->setState(RUNNING, clock); //change state of the front of the vector
            ticksCPU = Ready.front()->getNextCPUTime(); //get the CPUtime of the new process
            //cout << "ticksCPU: " << ticksCPU << endl;
            pRunCPU = Ready.front(); //assign front of queue to the cpu
            
            Ready.erase(Ready.begin()); //remove from ready since now running <--- used if Ready is a vector
            
            cpuReady = false; //cpu is now running this process

            //cout << "New process in CPU\n";
            pRunCPU ->output();
        } else if (pRunCPU != NULL){ //if the cpu is executing a process 
            ticksCPU--; //decrements the amount of time left for the process
            if (ticksCPU <= 0){ //if the tick number is 0 (the process is done)
                //cout << "CPU Done\n";
                cpuReady=true; //signal current process is done
                if(pRunCPU->checkEnd()){ //if the current process is done with its alloted burst time
                    Exit.push_back(pRunCPU); //push the process to the exit state queue
                    pRunCPU->getpcb()->setState(EXIT, clock);
                } else { //if the process is not done (there are more cpu bursts)
                    pRunCPU->startWait(clock);
                    Waiting.push_back(pRunCPU); //push the process to the waiting queue
                    pRunCPU->getpcb()->setState(WAITING, clock);
                }
                pRunCPU->output();
                pRunCPU = NULL; //making sure things work as intended
            }
        }
        if (ioReady && !Waiting.empty()){
            selectSort(Waiting); //this is the big difference between SPN and FCFS. the waiting vector is sorted


            Waiting.front()->getpcb()->setState(IORUN, clock);
            ticksIO = Waiting.front()->getNextIOTime();
            //cout << "ticksIO: " << ticksIO << endl;
            pRunIO = Waiting.front(); //assign front of queue to the cpu
            //Waiting.pop(); //remove front element from waiting since now running
            
            Waiting.erase(Waiting.begin()); //remove from waiting queue since now running

            ioReady = false; //cpu is now running this process
            //cout << "New process in IO\n ";
            pRunIO ->output();
        } else if (pRunIO != NULL) { //if the cpu is executing a process or ready queue is empty
            ticksIO--; //decrements the amount of time left for the process
            if (ticksIO <= 0){ //if the tick number is 0 (the process is done)
                //cout << "IO Done\n";
                ioReady=true; //signal current process is done
                if(pRunIO->checkEnd()){ //if the current process is done
                    pRunIO->getpcb()->setState(EXIT,clock); //set the state of the currently running IO process to exit
                    Exit.push_back(pRunIO); //push the currently running io process to the exit vector
                } else { //if the current process is not done
                    Ready.push_back(pRunIO); //push the current running io process
                    pRunIO->getpcb()->setState(READY,clock); //set the state of the currently running 
                }
                pRunIO ->output();
                pRunIO = NULL;
            }
        }
    }

    //calculate times now
    float throughput = float(p.size())/float(clock); //throughput is generally # of processes over time quantum, which is the amount of clock ticks in our case
    float turnaround = averageTurnaround(Exit); //gets the average time of all processes from entering ready state to exit state
    float avgWait = averageWaitTime(Exit); //gets average wait time of all processes that have completed (all time spent in waiting state)
    float avgResponse = averageResponseTime(Exit); //gets average response time of all processes that have completed (time from first ready until first running states)
    //float avgContextSwitch = averageContactSwitch(Exit); //
    float utilTime = (float(util)/float(clock))*100; //utilization % = (time in running / total time) * 100
    cout << "util: " << util << " clock: " << clock << " utilTime: " << utilTime << endl;
    string filename2 = "../bin/outputData.csv"; //string for relative path of file to open (for writing output of scheduling algorithms)
    fstream outData(filename2, ios::out | ios::app); //open specified filename in output mode  (write)
    dataGen(outData,"SPN", throughput, turnaround, avgWait, avgResponse, utilTime);
    outData.close();
}


int main() {
    //can run with "g++ -o exec *.cpp"
    srand(time(NULL)); //seeds time for rand()

    vector<Process> processes; //vector of processes

    string filename1 = "../bin/processData.csv"; //string for relative path of file to open (for processes)
    string filename2 = "../bin/outputData.csv"; //string for relative path of file to open (for writing output of scheduling algorithms)
    fstream procData(filename1, ios::out); //open the specified filename at the beginning in output mode (write)
    fstream outData(filename2, ios::out | ios::app); //open specified filename in output mode  (write)
    int procNum = (rand()%100)+500; //the number of processes is a random number, easily changed
    procFileGen(procData, procNum, processes); //make a file with random number of processes, writes these processes to a processes vector too

    procData.open(filename1, ios::in); //open specified filename at beginning in input mode (read)
    cout << "FCFS\n";
    firstComeFirstServe(processes);

    cout << "\n\nNOW SPN\n\n";

    shortestProcessNext(processes);

    cout << "\n\nNOW LS\n\n";
    // float sum = 0;
    // int numruns = 100;
    // for (int i = 0; i < numruns; i++){
    //     cout << i << endl;
    //     sum += loadSharing(processes);
    // }
    // sum /= 100;
    // cout << "AVERAGE WITH " << numProcessors << " : " << sum;
    loadSharing(processes);


    int timeAlloted = (rand()%11)+10; //rand time between 10 and 20 (inclusive)
    cout << "\n\nRR running with Time Quantum " << timeAlloted << "\n\n";
    RoundRob(processes, timeAlloted); //runs the round robin process with a random amount of time.
    cout << "\ndone\n";
    procData.close(); //close procData file
    outData.close(); //close outData file
}